import ProfileCards from '../components/profileCards'
import React from 'react';
import {Paper,Grid} from "@material-ui/core"
import './aboutUs.css';


export default class AboutUs extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            wahyu : {
                nama : "Wahyu Koco",
                nim : "00000040112"
            },
            veren : {
                nama : "Veren Valensia",
                nim : "00000040923"
            },
            vincent : {
                nama : "Vincent CH",
                nim : "00000040732"
            },
            feiza : {
                nama : "Feiza Joane",
                nim : "00000040124"
            },
            socialMed : {
                facebook : ""
            }
        }
    }

    render(){
        const user = this.state;
        return(
            <>
            <Grid container direction={column} justify="center" align="center">
    <Grid container item md={8} spacing={4} >
        <Grid item md={4}>
            <ProfileCards nama={user.wahyu.nama} nim={user.wahyu.nim}/>
        </Grid>
        <Grid item md={4}>
            <ProfileCards  nama={user.veren.nama} nim={user.veren.nim}/>
        </Grid>
    </Grid>
    <Grid container item md={8} spacing={4}>
        <Grid item md={4}>
            <ProfileCards nama={user.vincent.nama} nim={user.vincent.nim}/>
        </Grid>
        <Grid item md={4}>
            <ProfileCards nama={user.feiza.nama} nim={user.feiza.nim}/>
        </Grid>
    </Grid>
</Grid>
            </>
        );
    }
}