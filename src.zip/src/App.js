import './App.css';
import React from 'react'
import AboutUs from './pages/aboutUs'

function App() {
  return (
    <div className="App">
        <AboutUs/>
    </div>
  );
}

export default App;
